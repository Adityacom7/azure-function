import azure.functions as func
import logging

app = func.FunctionApp()

@app.blob_trigger(
    arg_name="myblob",
    path="insights-logs-storageread/{name}",
    connection="AzureWebJobsStorage"
)
def blob_trigger(myblob: func.InputStream):
    container_name = myblob.name.split('/')[0]
    object_name = myblob.name.split('/', 1)[1]

    logging.info(f"Bucket Name : {container_name}")
    logging.info(f"Object Name : {object_name}")